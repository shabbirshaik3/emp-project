package com.tcs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpmgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
